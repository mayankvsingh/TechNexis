# TechPlus Inc Website

A modern, responsive website for TechPlus Inc - Oracle SAP and SOA consulting services.

## Live Website
🌐 **Live URL**: https://azyqzvbf.manus.space

## Project Structure
```
techplus-website/
├── src/
│   ├── assets/
│   │   └── dhirendra-singh.png    # CEO photo
│   ├── components/
│   │   └── ui/                    # Shadcn/UI components
│   ├── App.jsx                    # Main application component
│   ├── App.css                    # Global styles
│   └── main.jsx                   # Entry point
├── public/
├── dist/                          # Built files for production
├── package.json                   # Dependencies and scripts
└── vite.config.js                # Vite configuration
```

## Features
✅ **Responsive Design** - Works on desktop, tablet, and mobile
✅ **Modern UI** - Built with React, Tailwind CSS, and Shadcn/UI
✅ **Dynamic Navigation** - Single-page application with tab navigation
✅ **Professional Content** - Showcases services, pricing, clients, and team

### Pages Included:
1. **Home** - Hero section, stats, services overview
2. **Products** - Oracle, SAP, and SOA product listings
3. **Pricing** - Competitive pricing tiers (Starter, Professional, Enterprise)
4. **Clients** - Client portfolio and testimonials
5. **Team** - CEO profile with high-definition photo

## Local Development Setup

### Prerequisites
- Node.js (v18 or higher)
- npm or pnpm

### Installation
1. Extract the zip file
2. Navigate to the project directory:
   ```bash
   cd techplus-website
   ```

3. Install dependencies:
   ```bash
   npm install
   # or
   pnpm install
   ```

4. Start the development server:
   ```bash
   npm run dev
   # or
   pnpm run dev
   ```

5. Open your browser and visit: `http://localhost:5173`

### Building for Production
```bash
npm run build
# or
pnpm run build
```

The built files will be in the `dist/` directory.

## Customization

### Editing Content
- **Main content**: Edit `src/App.jsx`
- **Styles**: Modify `src/App.css` or use Tailwind classes
- **Images**: Replace files in `src/assets/`

### Key Sections to Customize:
1. **Company Stats** (line ~25 in App.jsx)
2. **Services** (line ~35 in App.jsx)
3. **Products** (line ~55 in App.jsx)
4. **Pricing Plans** (line ~85 in App.jsx)
5. **Client List** (line ~125 in App.jsx)
6. **Team Information** (line ~145 in App.jsx)

### Color Scheme
The website uses a blue and purple gradient theme. To change colors, modify the CSS variables in `src/App.css`.

## Technologies Used
- **React** - Frontend framework
- **Vite** - Build tool
- **Tailwind CSS** - Utility-first CSS framework
- **Shadcn/UI** - Component library
- **Lucide React** - Icon library
- **Framer Motion** - Animation library

## Deployment
The website is currently deployed at: https://azyqzvbf.manus.space

To deploy your changes, you can use any static hosting service like:
- Vercel
- Netlify
- GitHub Pages
- AWS S3

## Support
For questions or support, contact: info@techplusinc.ai

---
© 2025 TechPlus Inc. All rights reserved.

