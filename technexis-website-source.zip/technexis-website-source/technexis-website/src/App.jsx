import React, { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import {
  Building2,
  Users,
  MapPin,
  CheckCircle,
  Star,
  ArrowRight,
  Database,
  Cloud,
  Settings,
  Shield,
  Globe,
  Zap,
  Award,
  TrendingUp,
  Phone,
  Mail,
  Linkedin
} from 'lucide-react'
import dhirendraPhoto from './assets/dhirendra-singh.png'
import technexis from './assets/technexis.png'
import './App.css'
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from '@/components/ui/dialog.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { useForm } from 'react-hook-form';

function App() {
  const [activeTab, setActiveTab] = useState('home')
  const [queryOpen, setQueryOpen] = useState(false);
  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  const onSubmit = (data) => {
    // You can handle the form submission here (e.g., send to API)
    alert(`Thank you, ${data.name}! We have received your query.`);
    setQueryOpen(false);
    reset();
  };

  const stats = [
    { icon: Users, label: 'Happy Clients', value: '150+' },
    { icon: MapPin, label: 'Global Locations', value: '8' },
    { icon: CheckCircle, label: 'Projects Completed', value: '500+' },
    { icon: Award, label: 'Years Experience', value: '15+' }
  ]

  const services = [
    {
      icon: Database,
      title: 'Oracle ERP Solutions',
      description: 'Complete Oracle ERP implementation, customization, and support services for streamlined business operations.'
    },
    {
      icon: Settings,
      title: 'SAP Business Solutions',
      description: 'End-to-end SAP implementation and consulting services tailored for small and medium enterprises.'
    },
    {
      icon: Cloud,
      title: 'SOA Architecture',
      description: 'Service-Oriented Architecture design and implementation for scalable, flexible business systems.'
    }
  ]

  const about = [
    {
      category: "Our Mission",
      items: [
        "Empower small and medium businesses with enterprise-grade solutions.",
        "Deliver affordable, scalable, and reliable technology.",
        "Build long-term partnerships with our clients."
      ]
    },
    {
      category: "Our Vision",
      items: [
        "Be the leading provider of Oracle, SAP, and SOA solutions for SMEs.",
        "Innovate continuously to meet evolving business needs.",
        "Foster a culture of excellence and integrity."
      ]
    },
    {
      category: "Our Values",
      items: [
        "Customer Success",
        "Transparency",
        "Innovation",
        "Collaboration",
        "Quality"
      ]
    }
  ]

  const servicesList = [
    {
      category: 'Application Development',
      items: [
        "Application Development is a key component in the quest to gain a competitive edge. This makes it critical that the project is done right without cost or time overruns. We ensure that our Application Development solution aligns to the client's business imperatives.",
        "TechNexis provides a completely customized application development solution whether departmental, divisional, or enterprise-wide in scope. We are equipped to provide a total solution around client needs, in a combination environment of our Onsite-Offshore Delivery Methodology.",
        "Our solutions are customized to meet the needs of client's unique industry or business. Our development teams use industry-accepted practices, such as object-oriented analysis and design techniques, as well as, industry-leading Application Development tools. A dedicated Product Release team, working closely with the client, takes care of complete testing and roll out of the final solution."
      ]
    }
  ]

  const consulting = [
    {
      category: 'For Employers',
      items: [
        "TechNexis is well-equipped to finding high-caliber employees with the right combination of education, experience and skills. Our extensive industry experience helps in determining the most efficient solution that fits your long- and short-term objectives and requirements."
      ]
    },
    {
      category: 'For Job Seekers',
      items: [
        "At TechNexis, we understand how stressful a job search can be. That is why we are dedicated to helping job seekers find the right assignment based on their skills, experience, and goals. TechNexis offers opportunities at leading companies with benefits like job flexibility and professional growth."
      ]
    }
  ]

  const products = [
    {
      category: 'Oracle Products',
      items: [
        'Oracle ERP Cloud',
        'Oracle Fusion Middleware',
        'Oracle Database Solutions',
        'Oracle Integration Cloud',
        'Oracle Analytics Cloud'
      ]
    },
    {
      category: 'SAP Products',
      items: [
        'SAP Business One',
        'SAP S/4HANA',
        'SAP SuccessFactors',
        'SAP Ariba',
        'SAP Concur'
      ]
    },
    {
      category: 'SOA Services',
      items: [
        'Enterprise Service Bus',
        'Web Services Development',
        'API Management',
        'Microservices Architecture',
        'Integration Platforms'
      ]
    }
  ]

  const pricingPlans = [
    {
      name: 'Starter',
      price: '$2,500',
      period: 'One-time',
      description: 'Perfect for small businesses starting their digital transformation',
      features: [
        'Basic ERP setup',
        'Up to 5 users',
        '3 months support',
        'Standard training',
        'Email support'
      ]
    },
    {
      name: 'Professional',
      price: '$899',
      period: 'Monthly',
      description: 'Ideal for growing businesses with advanced needs',
      features: [
        'Full ERP implementation',
        'Up to 25 users',
        'Ongoing support',
        'Advanced training',
        'Priority support',
        'Custom integrations'
      ],
      popular: true
    },
    {
      name: 'Enterprise',
      price: '$8,999',
      period: 'Yearly',
      description: 'Comprehensive solution for large organizations',
      features: [
        'Complete enterprise suite',
        'Unlimited users',
        '24/7 support',
        'On-site training',
        'Dedicated account manager',
        'Custom development',
        'Advanced analytics'
      ]
    }
  ]

  const clients = [
    { name: 'TechCorp Solutions', industry: 'Technology', logo: '🏢' },
    { name: 'Global Manufacturing', industry: 'Manufacturing', logo: '🏭' },
    { name: 'FinanceFirst', industry: 'Financial Services', logo: '🏦' },
    { name: 'HealthCare Plus', industry: 'Healthcare', logo: '🏥' },
    { name: 'RetailMax', industry: 'Retail', logo: '🛍️' },
    { name: 'EduTech Institute', industry: 'Education', logo: '🎓' }
  ]

  const testimonials = [
    {
      name: 'Sarah Johnson',
      company: 'TechCorp Solutions',
      text: 'TechNexis transformed our business operations with their Oracle ERP solution. Highly recommended!',
      rating: 5
    },
    {
      name: 'Michael Chen',
      company: 'Global Manufacturing',
      text: 'Outstanding SAP implementation. The team was professional and delivered on time.',
      rating: 5
    },
    {
      name: 'Emily Rodriguez',
      company: 'FinanceFirst',
      text: 'Their SOA architecture design improved our system integration significantly.',
      rating: 5
    }
  ]

  const Navigation = () => (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="bg-white rounded-full p-2 shadow-md flex items-center justify-center" style={{height: '96px', width: '96px'}}>
                <img src={technexis} alt="TechNexis Logo" className="h-20 w-20 object-contain" style={{mixBlendMode: 'multiply'}} />
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-8">
            <button
              onClick={() => setActiveTab('home')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'home' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setActiveTab('about')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'about' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              About Us
            </button>
            <button
              onClick={() => setActiveTab('services')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'services' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Services
            </button>
            <button
              onClick={() => setActiveTab('consulting')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'consulting' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Consulting
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'products' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Products
            </button>
            <button
              onClick={() => setActiveTab('pricing')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'pricing' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Pricing
            </button>
            <button
              onClick={() => setActiveTab('clients')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'clients' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Clients
            </button>
            <button
              onClick={() => setActiveTab('team')}
              className={`px-3 py-2 text-sm font-medium ${
                activeTab === 'team' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              Team
            </button>
            <Dialog open={queryOpen} onOpenChange={setQueryOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setQueryOpen(true)}>Get Started</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Get Started with TechNexis</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Name</Label>
                    <Input id="name" {...register('name', { required: 'Name is required' })} placeholder="Your Name" />
                    {errors.name && <span className="text-red-500 text-xs">{errors.name.message}</span>}
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" {...register('email', { required: 'Email is required' })} placeholder="you@email.com" />
                    {errors.email && <span className="text-red-500 text-xs">{errors.email.message}</span>}
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone (with country code)</Label>
                    <Input id="phone" type="tel" {...register('phone', { required: 'Phone is required' })} placeholder="+1 234 567 8901" />
                    {errors.phone && <span className="text-red-500 text-xs">{errors.phone.message}</span>}
                  </div>
                  <DialogFooter>
                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">Submit</Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </nav>
  )

  const HomePage = () => (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Transform Your Business with
              <span className="block text-yellow-300">Oracle, SAP & SOA Solutions</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              Affordable enterprise solutions for small and medium businesses.
              Get the power of big enterprise systems without the big enterprise costs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Dialog open={queryOpen} onOpenChange={setQueryOpen}>
                <DialogTrigger asChild>
                  <Button size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-black" onClick={() => setQueryOpen(true)}>
                    Start Your Project
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Get Started with TechNexis</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Name</Label>
                      <Input id="name" {...register('name', { required: 'Name is required' })} placeholder="Your Name" />
                      {errors.name && <span className="text-red-500 text-xs">{errors.name.message}</span>}
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" {...register('email', { required: 'Email is required' })} placeholder="you@email.com" />
                      {errors.email && <span className="text-red-500 text-xs">{errors.email.message}</span>}
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone (with country code)</Label>
                      <Input id="phone" type="tel" {...register('phone', { required: 'Phone is required' })} placeholder="+1 234 567 8901" />
                      {errors.phone && <span className="text-red-500 text-xs">{errors.phone.message}</span>}
                    </div>
                    <DialogFooter>
                      <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">Submit</Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">
                  <stat.icon className="h-12 w-12 text-blue-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Core Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We specialize in delivering enterprise-grade solutions that are accessible and affordable for growing businesses.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <service.icon className="h-12 w-12 text-blue-600 mb-4" />
                  <CardTitle>{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{service.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose TechNexis?
            </h2>
            <p className="text-xl text-gray-600">
              We're not like the big consulting firms. We focus on what matters to you.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Affordable Pricing</h3>
              <p className="text-gray-600">Get enterprise solutions at SME-friendly prices</p>
            </div>
            <div className="text-center">
              <Zap className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Fast Implementation</h3>
              <p className="text-gray-600">Quick deployment with minimal business disruption</p>
            </div>
            <div className="text-center">
              <Globe className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Global Support</h3>
              <p className="text-gray-600">24/7 support across multiple time zones</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )

  const AboutPage = () => (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About Us</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our Mission
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {about.map((category, index) => (
            <Card key={index} className="h-full">
              <CardHeader>
                <CardTitle className="text-2xl text-blue-600">{category.category}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {category.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )

  // Beautified ServicesPage
  const ServicesPage = () => (
    <div className="min-h-screen py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-blue-700 mb-4">Our Services</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We deliver tailored solutions to help your business grow and thrive in the digital age.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {services.map((service, index) => (
            <Card key={index} className="hover:shadow-xl transition-shadow border-0 bg-white rounded-2xl p-6 flex flex-col items-center text-center">
              <service.icon className="h-14 w-14 text-blue-600 mb-6" />
              <CardTitle className="text-2xl mb-2 text-blue-700">{service.title}</CardTitle>
              <CardDescription className="text-base text-gray-600 mb-4">{service.description}</CardDescription>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  // Beautified ConsultingPage
  const ConsultingPage = () => (
    <div className="min-h-screen py-20 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-blue-700 mb-4">Consulting</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Expert guidance for employers and job seekers in the tech industry.
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-10">
          {consulting.map((category, index) => (
            <Card key={index} className="hover:shadow-xl transition-shadow border-0 bg-blue-50 rounded-2xl p-8 flex flex-col">
              <CardTitle className="text-2xl mb-4 text-blue-700">{category.category}</CardTitle>
              <ul className="space-y-4 text-gray-700 text-lg">
                {category.items.map((item, itemIndex) => (
                  <li key={itemIndex} className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 mt-1" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const ProductsPage = () => (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Products & Services</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive Oracle, SAP, and SOA solutions tailored for your business needs
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {products.map((category, index) => (
            <Card key={index} className="h-full">
              <CardHeader>
                <CardTitle className="text-2xl text-blue-600">{category.category}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {category.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )

  const PricingPage = () => (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Competitive Pricing</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Transparent pricing that fits your budget. No hidden fees, no surprises.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {pricingPlans.map((plan, index) => (
            <Card key={index} className={`relative ${plan.popular ? 'border-blue-500 border-2' : ''}`}>
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600">
                  Most Popular
                </Badge>
              )}
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <div className="text-4xl font-bold text-blue-600">
                  {plan.price}
                  <span className="text-lg text-gray-600">/{plan.period}</span>
                </div>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button className="w-full" variant={plan.popular ? "default" : "outline"}>
                  Get Started
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )

  const ClientsPage = () => (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Valued Clients</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Trusted by businesses across various industries worldwide
          </p>
        </div>

        {/* Client Logos */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 mb-20">
          {clients.map((client, index) => (
            <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-4">{client.logo}</div>
              <h3 className="font-semibold text-gray-900">{client.name}</h3>
              <p className="text-sm text-gray-600">{client.industry}</p>
            </Card>
          ))}
        </div>

        {/* Testimonials */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">What Our Clients Say</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-6">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">"{testimonial.text}"</p>
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.company}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )

  const TeamPage = () => (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Meet Our Team</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Led by experienced professionals dedicated to your success
          </p>
        </div>

        <div className="flex justify-center">
          <Card className="max-w-md text-center">
            <CardHeader>
              <div className="w-48 h-48 mx-auto mb-6 rounded-full overflow-hidden">
                <img
                  src={dhirendraPhoto}
                  alt="Dhirendra Singh"
                  className="w-full h-full object-cover"
                />
              </div>
              <CardTitle className="text-2xl">Dhirendra Singh</CardTitle>
              <CardDescription className="text-lg text-blue-600 font-semibold">
                CEO & Founder
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-6">
                With over 15 years of experience in enterprise software consulting,
                Dhirendra founded TechNexis with a vision to make enterprise-grade
                solutions accessible to small and medium businesses.
              </p>
              <div className="flex justify-center space-x-4">
                <Button variant="outline" size="sm">
                  <Mail className="h-4 w-4 mr-2" />
                  Email
                </Button>
                <Button variant="outline" size="sm">
                  <Linkedin className="h-4 w-4 mr-2" />
                  LinkedIn
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )

  const Footer = () => (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Building2 className="h-8 w-8 text-blue-400" />
              <span className="ml-2 text-xl font-bold">TechNexis</span>
            </div>
            <p className="text-gray-400">
              Transforming businesses with affordable Oracle, SAP, and SOA solutions.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Oracle ERP</li>
              <li>SAP Solutions</li>
              <li>SOA Architecture</li>
              <li>Implementation</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2 text-gray-400">
              <li>About Us</li>
              <li>Careers</li>
              <li>Contact</li>
              <li>Blog</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <div className="space-y-2 text-gray-400">
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-2" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-2" />
                <span>info@technexis.ai</span>
              </div>
              <div className="flex items-center">
                <Globe className="h-4 w-4 mr-2" />
                <span>TechNexis.ai</span>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2025 TechNexis All rights reserved.</p>
        </div>
      </div>
    </footer>
  )

  const renderContent = () => {
    switch (activeTab) {
      case 'about':
        return <AboutPage />
      case 'products':
        return <ProductsPage />
      case 'services':
        return <ServicesPage />
      case 'consulting':
        return <ConsultingPage />
      case 'pricing':
        return <PricingPage />
      case 'clients':
        return <ClientsPage />
      case 'team':
        return <TeamPage />
      default:
        return <HomePage />
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      {renderContent()}
      <Footer />
    </div>
  )
}

export default App
